from app import create_app
from app import db

application = create_app()

